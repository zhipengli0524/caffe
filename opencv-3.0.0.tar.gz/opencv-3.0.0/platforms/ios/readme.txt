Building OpenCV from Source, using CMake and Command Line
=========================================================

cd ~/<my_working_directory>
python opencv/platforms/ios/build_framework.py ios

If everything's fine, a few minutes later you will get ~/<my_working_directory>/ios/opencv2.framework. You can add this framework to your Xcode projects.
